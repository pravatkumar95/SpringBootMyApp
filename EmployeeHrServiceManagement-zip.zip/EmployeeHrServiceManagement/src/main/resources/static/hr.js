var stompClient=null



   function sendMessage(){
  console.log("connected")

   var inputElement=document.getElementById("send-btn");
   var message=inputElement.value;
   

    stompClient.send("/app/empWebsock",{},JSON.stringify(message));



   }



function connect()
{

        let socket=new SockJS("/myApp")

        stompClient=Stomp.over(socket)

        stompClient.connect({},function(frame){

            console.log("Connected : "+frame)

            


                //subscribe
                stompClient.subscribe("/topic/hr",function(response){

                        showMessage(JSON.parse(response.body))

                })



        })

}

function showMessage(message){
	var response = document.getElementById('response#1');
	
	 response.innerHTML=message;
                var p = document.createElement('p');
                p.style.wordWrap = 'break-word';
                p.appendChild(document.createTextNode(message));
                  p.appendChild(document.createTextNode(message.id + ": " 
                  + message.name+":"+message.status));

	
	  
	
}
 

$(document).ready((e)=>{


   /*$("#connect").click(()=>{
       connect();


   })*/

     $("form").on('submit', (e) => e.preventDefault());
   $("#send-btn").click(()=>{
    sendMessage()
   })


})
