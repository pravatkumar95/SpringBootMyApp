var stompClient=null



   function sendMessage(){


   var empID=document.getElementById("emp-id");
   var empName=document.getElementById("emp-name");
   
   
   var id=empID.value;
   var name=empName.value;
   
   
   let employee={
	   id:id,
	   name:name
   }
   const dataSend=JSON.stringify(employee);

    stompClient.send("/app/empWebsock",{},dataSend);

   }



function connect()
{

        let socket=new SockJS("/myApp")

        stompClient=Stomp.over(socket)

        stompClient.connect({},function(frame){

            console.log("Connected : "+frame)



        })

}


 function showMessage(message)
 {

    //$("#message-container-table").prepend(`<tr><td><b>${message.name} :</b> ${message.content}</td></tr>`)

 }





$(document).ready((e)=>{

   

   $("#connect").click(()=>{
       connect();


   })
   
    $("form").on('submit', (e) => e.preventDefault());

   $("#send-btn").click(()=>{
    sendMessage()
   })


})