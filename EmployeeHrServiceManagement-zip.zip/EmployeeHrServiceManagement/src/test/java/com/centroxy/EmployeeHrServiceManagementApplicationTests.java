package com.centroxy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeHrServiceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
