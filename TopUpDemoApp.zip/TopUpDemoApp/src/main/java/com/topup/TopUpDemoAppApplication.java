package com.topup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TopUpDemoAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(TopUpDemoAppApplication.class, args);
    }

}
