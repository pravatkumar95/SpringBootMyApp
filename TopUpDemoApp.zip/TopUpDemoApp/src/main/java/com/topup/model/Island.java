package com.topup.model;

public enum Island {
    JSY,GSY
}
