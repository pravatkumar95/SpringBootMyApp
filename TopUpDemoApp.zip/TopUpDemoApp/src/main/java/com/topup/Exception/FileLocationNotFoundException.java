package com.topup.Exception;

public class FileLocationNotFoundException extends RuntimeException {


    public FileLocationNotFoundException(String message) {
        super(message);

    }
}
